1. Extract zip file
2. Truncate Database and Run Script

Database: 
	password will stored as hash and slat format (encripted)

API: 
     Check Database Connection and Run Project
UI: 
    1. if nodemodule folder not there then run command "npm install"
2. then run npm start
3. first register with admin
then Accounts
then SuperAdmin
4. Admins will do roll off flow
5. once admin done then login with Accounts user do the flow
6. after that login with super admin

Remainnig:
1. Auto reflect 
2. touchup and Fininshing


Note: we had discussion will delever u this project on friday.  flow is completed, other changes not completed due to time issue.. 