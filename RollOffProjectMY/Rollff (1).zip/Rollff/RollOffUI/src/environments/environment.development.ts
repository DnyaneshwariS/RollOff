export const environment = {
    production:true,
    baseApiUrl:"https://localhost:44362/api/"
};
