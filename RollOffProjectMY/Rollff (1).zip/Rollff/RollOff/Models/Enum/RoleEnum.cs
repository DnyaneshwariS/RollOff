﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RollOff.Models.Enum
{
    public enum RoleEnum
    {
        Admin,
        Accounts,
        SuperAdmin,
    }
}
